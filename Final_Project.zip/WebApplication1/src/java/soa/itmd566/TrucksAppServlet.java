/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soa.itmd566;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;
import org.my.ns.CountMaintenanceModel;
import org.my.ns.CountTruckMaintenanceInfo;
import org.my.ns.CustomerPaymentModel;
import org.my.ns.CustomerpaymentInfo;
import org.my.ns.CustomersInfo;
import org.my.ns.CustomersModel;
import org.my.ns.Exception_Exception;
import org.my.ns.InvoiceInfo;
import org.my.ns.InvoiceModel;
import org.my.ns.LocationCountInfo;
import org.my.ns.LocationCountModel;
import org.my.ns.MaintenanceInfo;
import org.my.ns.MaintenanceModel;
import org.my.ns.TruckDetails;
import org.my.ns.TruckMaintenanceByDate;
import org.my.ns.TrucksModel;
import org.my.ns.VehicleDetails;
import org.my.ns.VehiclesModel;

/**
 *
 * @author Arun Hundia
 */
@WebServlet(name = "TrucksAppServlet", urlPatterns = {"/TrucksAppServlet"})
public class TrucksAppServlet extends HttpServlet {

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/TruckMaintenanceByDate?wsdl")
    private TruckMaintenanceByDate service_8;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/InvoiceInfo?wsdl")
    private InvoiceInfo service_7;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/CustomersInfo?wsdl")
    private CustomersInfo service_6;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/VehicleDetails?wsdl")
    private VehicleDetails service_5;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/TruckDetails?wsdl")
    private TruckDetails service_4;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/CountTruckMaintenanceInfo?wsdl")
    private CountTruckMaintenanceInfo service_3;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/MaintenanceInfo?wsdl")
    private MaintenanceInfo service_2;

    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/LocationCountInfo?wsdl")
    private LocationCountInfo service_1;
    
    @WebServiceRef(wsdlLocation = "http://localhost:8080/WebServiceImplementation/customerpaymentInfo?wsdl")
    private CustomerpaymentInfo service;
    
List<CustomerPaymentModel> test = new ArrayList<>();
List<LocationCountModel> locationCount = new ArrayList<>();
List<MaintenanceModel> maintenance = new ArrayList<>();
List<CountMaintenanceModel> countmaintenance = new ArrayList<>();
List<TrucksModel> trucksinfo = new ArrayList<>();
List<VehiclesModel> vehicleinfo = new ArrayList<>();
List<CustomersModel> customersinfo = new ArrayList<>();
List<InvoiceModel> invoicesinfo = new ArrayList<>();
    

    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          String start_date=request.getParameter("start_date");
        String end_date = request.getParameter("end_date");  
         if(start_date!=null || end_date!=null)
            
        {
            org.my.ns.WebService4 port = service_8.getWebService4Port();
            try {
        maintenance=port.getTruckByMaintenanceDate(start_date, end_date);
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
        out.print("<b>Maintenance Report based on Year</b>");
        out.print("<br><br>");
        out.println("<table class='table' border=1>");  
        out.println("<thead>");
        out.println("<th><center>Maintenance ID</center></th>");
        out.println("<th><center>Truck ID</center></th>");
        out.println("<th><center>Description</center></th>");
        out.println("<th><center>Maintenance Date</center></th>");
        out.println("<th><center>Cost</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(MaintenanceModel mainmodel:maintenance)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+mainmodel.getMaintenanceId()+"</center></td>");
              out.println("<td><center>"+mainmodel.getTruckId()+"</center></td>");
              out.println("<td><center>"+mainmodel.getDescription()+"</center></td>");
              out.println("<td><center>"+mainmodel.getMaintenanceDate()+"</center></td>");
              out.println("<td><center>"+"$ "+mainmodel.getCost()+"</center></td>");
              
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
        }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        
        String button;
        button=request.getParameter("act");
        
        //out.print(button);
       
        if(button.equals("Info"))
        {
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService1 port = service_4.getWebService1Port();
    try {
        trucksinfo=port.getTruckDetails();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
        out.print("<b>Trucks Info</b>");
        out.print("<br/><br/>");
        out.println("<table class ='table' border=1>");
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Truck ID</center></th>");
        out.println("<th><center>VIN</center></th>");
        out.println("<th><center>Model</center></th>");
        out.println("<th><center>Color</center></th>");
        out.println("<th><center>Capacity</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(TrucksModel trucks_model:trucksinfo)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+trucks_model.getTruckID()+"</center></td>");
              out.println("<td><center>"+trucks_model.getVin()+"</center></td>");
              out.println("<td><center>"+trucks_model.getModel()+"</center></td>");
              out.println("<td><center>"+trucks_model.getColor()+"</center></td>");
              out.println("<td><center>"+trucks_model.getCapacity()+"</center></td>");
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
        }
        
        else if(button.equals("vehicles_info"))
        {
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService2 port = service_5.getWebService2Port();
    try {
        vehicleinfo=port.getVehicleDetails();
        //out.println("<link rel='stylesheet' type='text/css' href='" + request.getContextPath() +  "/style.css'/>");
        
        //out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
  
       
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
out.println("<b>Vehicles Info</b>");
        out.print("<br/><br/>");
        out.println("<table class='table' border=1>");  
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center><center>Vehicle ID</center></center></th>");
        out.println("<th><center>VIN</center></th>");
        out.println("<th><center>Model</center></th>");
        out.println("<th><center>Make</center></th>");
        out.println("<th><center>Color</center></th>");
        out.println("<th><center>Year</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(VehiclesModel vehicle_model:vehicleinfo)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+vehicle_model.getVehicleID()+"</center></td>");
              out.println("<td><center>"+vehicle_model.getVin()+"</center></td>");
              out.println("<td><center>"+vehicle_model.getModel()+"</center></td>");
              out.println("<td><center>"+vehicle_model.getMake()+"</center></td>");
              out.println("<td><center>"+vehicle_model.getColor()+"</center></td>");
              out.println("<td><center>"+vehicle_model.getYear()+"</center></td>");
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
        }
        
       else if(button.equals("payment_info"))
        {
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService10 port = service.getWebService10Port();
    try {
        test=port.getcustomerpaymentInfo();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
        out.print("<b>Customer Payment Report</b>");
        out.print("<br/><br/>");
        out.println("<table class='table' border=1>");
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Payment ID</center></th>");
        out.println("<th><center>Invoice ID</center></th>");
        out.println("<th><center>Payment Date</center></th>");
        out.println("<th><center>Payment Method</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(CustomerPaymentModel cmodel:test)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+cmodel.getCustomerpaymentid()+"</center></td>");
              out.println("<td><center>"+cmodel.getInvoiceid()+"</center></td>");
              out.println("<td><center>"+cmodel.getDate()+"</center></td>");
              out.println("<td><center>"+cmodel.getPaymentmethod()+"</center></td>");
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
        }
       else if(button.equals("cust_info"))
        {
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService8 port = service_6.getWebService8Port();
    try {
        customersinfo=port.getcustomerInfo();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
        out.println("<body>");
        out.print("<br/>");
        out.print("<b>Customers Info</b>");
        out.print("<br><br>");
        out.println("<table class='table' border=1>");
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Customer ID</center></th>");
        out.println("<th><center>Contact Name</center></th>");
        out.println("<th><center>Business Name</center></th>");
        out.println("<th><center>Email ID</center></th>");
        out.println("<th><center>Country</center></th>");
        out.println("</thead>");
        out.println("</tr>");
          for(CustomersModel customer_model:customersinfo)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+customer_model.getCustomerID()+"</center></td>");
              out.println("<td><center>"+customer_model.getContactName()+"</center></td>");
              out.println("<td><center>"+customer_model.getBusinessName()+"</center></td>");
              out.println("<td><center>"+customer_model.getEmailAdd()+"</center></td>");
              out.println("<td><center>"+customer_model.getCountry()+"</center></td>");
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
        }
        else if(button.equals("cust_orders"))
        {
            
            
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService14 port = service_1.getWebService14Port();
    try {
        locationCount=port.getlocationcountCount();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
        out.print("<b>Count of orders location Wise</b>");
        out.print("<br><br>");
        out.println("<table class='table' border=1>");
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Location</center></th>");
        out.println("<th><center>Total Count</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(LocationCountModel lmodel:locationCount)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+lmodel.getLname()+"</center></td>");
              out.println("<td><center>"+lmodel.getTotalCount()+"</center></td>");
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } 
    catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
    
        }
        else if(button.equals("invoice"))
        {
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService9 port = service_7.getWebService9Port();
    try {
        invoicesinfo=port.getinvoiceInfo();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");

        out.print("<b>Invoices Info</b>");
        out.print("<br><br>");
        out.println("<table class='table' border=1>");  
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Invoice ID</center></th>");
        out.println("<th><center>Order ID</center></th>");
        out.println("<th><center>Business Name</center></th>");
        out.println("<th><center>Business Email ID</center></th>");
        out.println("<th><center>Business Phone Number</center></th>");
        
        out.println("</tr>");
        out.println("</thead>");
          for(InvoiceModel invoice_model:invoicesinfo)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+invoice_model.getInvoiceID()+"</center></td>");
              out.println("<td><center>"+invoice_model.getOrderID()+"</center></td>");
              out.println("<td><center>"+invoice_model.getBusinessName()+"</center></td>");
              out.println("<td><center>"+invoice_model.getBusinessEmail()+"</center></td>");
              out.println("<td><center>"+invoice_model.getBusinessPhone()+"</center></td>");
              
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
        }
        else if(button.equals("maintenance_info"))
        {
            
            
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService16 port = service_2.getWebService16Port();
    try {
        maintenance=port.getmaintenanceInfo();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
        out.print("<b>Maintenance Details</b>");
        out.print("<br><br>");
        out.println("<table class='table' border=1>");  
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Maintenance ID</center></th>");
        out.println("<th><center>Truck ID</center></th>");
        out.println("<th><center>Description</center></th>");
        out.println("<th><center>Maintenance Date</center></th>");
        out.println("<th><center>Cost</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(MaintenanceModel mainmodel:maintenance)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+mainmodel.getMaintenanceId()+"</center></td>");
              out.println("<td><center>"+mainmodel.getTruckId()+"</center></td>");
              out.println("<td><center>"+mainmodel.getDescription()+"</center></td>");
              out.println("<td><center>"+mainmodel.getMaintenanceDate()+"</center></td>");
              out.println("<td><center>"+"$ "+mainmodel.getCost()+"</center></td>");
              
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } 
    catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
    
        }
        else if(button.equals("maintenance_date"))
        {
            response.sendRedirect("getDate.jsp");
        }
        else if(button.equals("maintenance_report"))
        {
            
            
            response.setContentType("text/html;charset=UTF-8");
        org.my.ns.WebService17 port = service_3.getWebService17Port();
    try {
        countmaintenance=port.getcounttruckmaintenance();
        out.println("<html>");
        out.println("<head>");
        out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
        out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
        out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
        out.println("</head>");
out.println("<body>");
out.print("<br/>");
        out.print("<b>Maintenance Count on Trucks</b>");
        out.print("<br><br>");
        out.println("<table class='table' border=1>");  
        out.println("<thead>");
        out.println("<tr class='info'>");
        out.println("<th><center>Truck ID</center></th>");
        out.println("<th><center>Total Count</center></th>");
        out.println("</tr>");
        out.println("</thead>");
          for(CountMaintenanceModel cmaintenance:countmaintenance)
          {
              out.println("<tbody>");
              out.println("<tr class='success'>");
              out.println("<td><center>"+cmaintenance.getTruckId()+"</center></td>");
              out.println("<td><center>"+cmaintenance.getTotalCount()+"</center></td>");
              
              out.println("</tr>");
              out.println("</tbody>");
          }
          out.println("</table></body></html>");
    } 
    catch (Exception_Exception ex) {
        Logger.getLogger(TrucksAppServlet.class.getName()).log(Level.SEVERE, null, ex);
    } 
    
        }
        
        
    }
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    

    

    

    

    
    }

    

    

    

    


