package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "DriverTicketsById", targetNamespace = "http://my.org/ns/")
public class WebService6 {

    @WebMethod(operationName = "getDriverDetailsForId3")
    public String driverTicketById() throws Exception {
        
        ArrayList driverTicket = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select drivers.driver_license, drivers.driver_name, tickets.amount, tickets.description from drivers, tickets where drivers.driver_id= '" + 3 + "' AND drivers.driver_id=tickets.driver_id");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String license = rs.getString("driver_license");
                String name = rs.getString("driver_name");
                String amount = rs.getString("amount");
                String desc = rs.getString("description");
                                
                driverTicket.add(license);
                driverTicket.add(name);
                driverTicket.add(amount);
                driverTicket.add(desc);
                
            }
            System.out.println("Driver Ticket Details" + driverTicket.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return driverTicket.toString();
    }

}
