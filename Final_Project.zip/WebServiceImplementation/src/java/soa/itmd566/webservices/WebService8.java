package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;
import soa.itmd566.model.*;

/**
 *
 * @author Ojas
 * WebService to get Customer Details
 */
@WebService(serviceName = "CustomersInfo", targetNamespace = "http://my.org/ns/")
public class WebService8 {

    @WebMethod(operationName = "getcustomerInfo")
    public List<CustomersModel> customerinfoById() throws Exception {
        List<CustomersModel> customerinfo = new ArrayList<>();
        //ArrayList customerinfo = new ArrayList();
        CustomersModel custModel=null;
        
        try {
            
            Connection con = getConnection();
            String customerInfo="select customer_id, business_name,contactname, email, country from customers";
            PreparedStatement ps = con.prepareStatement(customerInfo);
            ResultSet rs = ps.executeQuery();
            
           
            while (rs.next()) {
                custModel = new CustomersModel();
                String custid = rs.getString("customer_id");
                custModel.setCustomerID(Integer.parseInt(custid));
                String bname = rs.getString("business_name");
                custModel.setBusinessName(bname);
                String contact_name = rs.getString("contactname");
                custModel.setContactName(contact_name);
                String emaild = rs.getString("email");
                custModel.setEmailAdd(emaild);
                String country = rs.getString("country");
                custModel.setCountry(country);
                customerinfo.add(custModel);

                //customerinfo.add(Arrays.asList(custid, bname,contact_name,emaild,country));
               
//                customerinfo.add(custid);
//                customerinfo.add(bname);
//                customerinfo.add(contact_name);
//                customerinfo.add(emaild);
//                customerinfo.add(country);
            } 
            
           // System.out.println("Customer Information" + customerinfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerinfo;
    }

}
