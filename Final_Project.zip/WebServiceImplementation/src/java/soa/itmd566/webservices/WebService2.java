package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import soa.itmd566.model.VehiclesModel;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get vehicle by id
 */
@WebService(serviceName = "VehicleDetails", targetNamespace = "http://my.org/ns/")
public class WebService2 {

    @WebMethod(operationName = "getVehicleDetails")
    public List<VehiclesModel> vehicleById() throws Exception {
        
        List<VehiclesModel> vehiclesinfo = new ArrayList<>();
        VehiclesModel vehicleModel=null;
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select vehicle_id,vin,colour,make,model,year from vehicles");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                vehicleModel = new VehiclesModel();
                String id = rs.getString("vehicle_id");
                vehicleModel.setVehicleID(Integer.parseInt(id));
                String vin = rs.getString("vin");
                vehicleModel.setVin(vin);
                String colour = rs.getString("colour");
                vehicleModel.setColor(colour);
                String make = rs.getString("make");
                vehicleModel.setMake(make);
                String model = rs.getString("model");
                vehicleModel.setModel(model);
                String year = rs.getString("year");
                vehicleModel.setYear(year);
                vehiclesinfo.add(vehicleModel);
                
            }
           

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehiclesinfo;
    }
    
    

}
