package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "CustomerVehicleInfo", targetNamespace = "http://my.org/ns/")
public class WebService20 {

    @WebMethod(operationName = "getcustomervehicleInfo")
    public String customervehicleById() throws Exception {
        
        ArrayList customervehicle = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select c.business_name,v.model from orderitems oi join orders o on oi.order_id=o.order_id join vehicles v on v.vehicle_id=oi.vehicle_id join customers c on c.customer_id=o.customer_id");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String business_name = rs.getString("business_name");
                String model = rs.getString("model");               
               
                

                
                customervehicle.add(business_name);
                 customervehicle.add(model);
                
            }
            System.out.println("Customer Vehicle Information" + customervehicle.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customervehicle.toString();
    }

}
