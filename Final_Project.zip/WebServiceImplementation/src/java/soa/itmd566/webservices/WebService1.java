package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import soa.itmd566.model.TrucksModel;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get truck details by id
 */
@WebService(serviceName = "TruckDetails", targetNamespace = "http://my.org/ns/")
public class WebService1 {

    @WebMethod(operationName = "getTruckDetails")
    public List<TrucksModel> truckById() throws Exception {
        List<TrucksModel> truckinfo = new ArrayList<>();
       
        TrucksModel truckModel=null;
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from trucks");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                
                truckModel = new TrucksModel();
                String id = rs.getString("truck_id");
                 truckModel.setTruckID(Integer.parseInt(id));
                String vin = rs.getString("vin");
                truckModel.setVin(vin);
                String colour = rs.getString("colour");
                truckModel.setColor(colour);
                String capacity = rs.getString("capacity");
                truckModel.setCapacity(capacity);
                String model = rs.getString("model");
                    truckModel.setModel(model);
                
                truckinfo.add(truckModel);
            }
           

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return truckinfo;
    }

}
