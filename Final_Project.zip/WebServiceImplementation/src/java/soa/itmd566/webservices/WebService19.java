package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "DriverTicketInfo", targetNamespace = "http://my.org/ns/")
public class WebService19 {

    @WebMethod(operationName = "getdriverticketInfo")
    public String driverticketById() throws Exception {
        
        ArrayList driverticket = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select d.driver_name,count(d.driver_name) Total_ticket, sum(t.amount) Total_Amount from tickets t join drivers d on t.driver_id=d.driver_id group by d.driver_name");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String dname = rs.getString("driver_name");
                String total_ticket = rs.getString("Total_ticket");               
                String total_amnt = rs.getString("Total_Amount");  
                

                
                driverticket.add(dname);
                 driverticket.add(total_ticket);
                 driverticket.add(total_amnt);
            }
            System.out.println("Driver ticket Information" + driverticket.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return driverticket.toString();
    }

}
