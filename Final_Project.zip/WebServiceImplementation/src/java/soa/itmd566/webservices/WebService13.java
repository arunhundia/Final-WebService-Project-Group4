package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "driverpaymentInfo", targetNamespace = "http://my.org/ns/")
public class WebService13 {

    @WebMethod(operationName = "getdriverpaymentInfo")
    public String driverpaymentInfoById() throws Exception {
        
        ArrayList driverpaymentInfo = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from driver_payment");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String payment_id = rs.getString("payment_id");
                String driver_id = rs.getString("driver_id");
                String amount = rs.getString("amount");
                String payment_method = rs.getString("payment_method");
                
                

                
                driverpaymentInfo.add(payment_id);
                driverpaymentInfo.add(driver_id);
                driverpaymentInfo.add(amount);
                driverpaymentInfo.add(payment_method);
                
            }
            System.out.println("Driver Payment Information" + driverpaymentInfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return driverpaymentInfo.toString();
    }

}
