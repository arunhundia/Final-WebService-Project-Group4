package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;
import soa.itmd566.model.*;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "customerlocationorderInfo", targetNamespace = "http://my.org/ns/")
public class WebService18 {

    @WebMethod(operationName = "getcustomerlocationorderInfo")
    public List<CustomerLocationOrderModel> customerlocationorderById() throws Exception {
        List<CustomerLocationOrderModel> customerlocationorder = new ArrayList<>();
        //ArrayList customerinfo = new ArrayList();
        CustomerLocationOrderModel custlocordercount=null;
        
        try {
            
            Connection con = getConnection();
            String maintenancesql="select c.business_name Business_Name,l.location_name Location_Name,sum(o.total_cost) Total_Cost from orders o join customers c on c.customer_id=o.customer_id join locations l on l.location_id=o.location_id group by c.business_name,l.location_name;";
            PreparedStatement ps = con.prepareStatement(maintenancesql);
            ResultSet rs = ps.executeQuery();
            
           
            while (rs.next()) {
                custlocordercount = new CustomerLocationOrderModel();
                String bname = rs.getString("Business_Name");
                custlocordercount.setBusiness_name(bname);
                String loc_name = rs.getString("Location_Name");
                custlocordercount.setLocation_name(loc_name);
                String total_cost = rs.getString("Total_Cost");
                custlocordercount.setTotal_cost(Integer.parseInt(total_cost));
                
                customerlocationorder.add(custlocordercount);

                //customerinfo.add(Arrays.asList(custid, bname,contact_name,emaild,country));
               
//                customerinfo.add(custid);
//                customerinfo.add(bname);
//                customerinfo.add(contact_name);
//                customerinfo.add(emaild);
//                customerinfo.add(country);
            } 
            
            System.out.println("Customer Location Cost Information" + customerlocationorder.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerlocationorder;
    }

}