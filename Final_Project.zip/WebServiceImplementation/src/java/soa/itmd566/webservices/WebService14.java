package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;
import soa.itmd566.model.*;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "LocationCountInfo", targetNamespace = "http://my.org/ns/")
public class WebService14 {

    @WebMethod(operationName = "getlocationcountCount")
    public List<LocationCountModel> locationcountById() throws Exception {
        List<LocationCountModel> locationcountinfo = new ArrayList<>();
        //ArrayList customerinfo = new ArrayList();
        LocationCountModel locModel=null;
        
        try {
            
            Connection con = getConnection();
            String locationInfo="select l.location_name Location_name,count(l.location_name) Total_Count from locations l join orders o on l.location_id=o.location_id group by l.location_name;";
            PreparedStatement ps = con.prepareStatement(locationInfo);
            ResultSet rs = ps.executeQuery();
            
           
            while (rs.next()) {
                locModel = new LocationCountModel();
                String location_name = rs.getString("Location_name");
                locModel.setLname(location_name);
                String lcount = rs.getString("Total_Count");
                locModel.setTotal_count(Integer.parseInt(lcount));
                
                locationcountinfo.add(locModel);

                //customerinfo.add(Arrays.asList(custid, bname,contact_name,emaild,country));
               
//                customerinfo.add(custid);
//                customerinfo.add(bname);
//                customerinfo.add(contact_name);
//                customerinfo.add(emaild);
//                customerinfo.add(country);
            } 
            
            System.out.println("Location Count" + locationcountinfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return locationcountinfo;
    }

}