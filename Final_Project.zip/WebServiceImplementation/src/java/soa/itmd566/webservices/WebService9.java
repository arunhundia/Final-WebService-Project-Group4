package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import soa.itmd566.model.InvoiceModel;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "InvoiceInfo", targetNamespace = "http://my.org/ns/")
public class WebService9 {

    @WebMethod(operationName = "getinvoiceInfo")
    public List<InvoiceModel> invoiceinfoById() throws Exception {
        
        List<InvoiceModel> invoiceInfo = new ArrayList<>();
        InvoiceModel invoiceModel;
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from invoice");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                invoiceModel = new InvoiceModel();
                String invoie_id = rs.getString("invoice_id");
                invoiceModel.setInvoiceID(Integer.parseInt(invoie_id));
                String order_id = rs.getString("order_id");
                invoiceModel.setOrderID(Integer.parseInt(order_id));
                String business_name = rs.getString("businessname");
                invoiceModel.setBusinessName(business_name);
                String business_phone = rs.getString("businessphone");
               invoiceModel.setBusinessPhone(business_phone);
                String busines_email = rs.getString("businessemail");
                 invoiceModel.setBusinessEmail(busines_email);
                invoiceInfo.add(invoiceModel);

                
                
            }
            

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return invoiceInfo;
    }

}
