package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import soa.itmd566.model.MaintenanceModel;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get Maintenance Record between two years
 */
@WebService(serviceName = "TruckMaintenanceByDate", targetNamespace = "http://my.org/ns/")
public class WebService4 {

    @WebMethod(operationName = "getTruckByMaintenanceDate")
    public List<MaintenanceModel> truckByMaintenanceDate(String syear, String eyear) throws Exception {
        
        List<MaintenanceModel> minfo = new ArrayList<>();
        
        MaintenanceModel mmodel;
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from maintenance where date_format(maintenance_date, '%Y') between '" + syear + "' AND '" + eyear + "'" );
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                mmodel = new MaintenanceModel();
                String id = rs.getString("maintenance_id");
                mmodel.setMaintenance_id(Integer.parseInt(id));
                String tid = rs.getString("truck_id");
                mmodel.setTruck_id(Integer.parseInt(tid));
                String desc = rs.getString("description");
                mmodel.setDescription(desc);
                String mdate = rs.getString("maintenance_date");
                mmodel.setMaintenance_date(mdate);
                String cost = rs.getString("cost");
                mmodel.setCost(Integer.parseInt(cost));
                    minfo.add(mmodel);            
                
                
            }
            

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return minfo;
    }

}
