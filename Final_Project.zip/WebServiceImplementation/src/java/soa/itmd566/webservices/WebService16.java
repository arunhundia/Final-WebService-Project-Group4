package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;
import soa.itmd566.model.*;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "MaintenanceInfo", targetNamespace = "http://my.org/ns/")
public class WebService16 {

    @WebMethod(operationName = "getmaintenanceInfo")
    public List<MaintenanceModel> maintenanceById() throws Exception {
        List<MaintenanceModel> maintenanceinfo = new ArrayList<>();
        //ArrayList customerinfo = new ArrayList();
        MaintenanceModel mainModel=null;
        
        try {
            
            Connection con = getConnection();
            String maintenancesql="Select maintenance_id, truck_id, description, maintenance_date,cost from maintenance;";
            PreparedStatement ps = con.prepareStatement(maintenancesql);
            ResultSet rs = ps.executeQuery();
            
           
            while (rs.next()) {
                mainModel = new MaintenanceModel();
                String mainid = rs.getString("maintenance_id");
                mainModel.setMaintenance_id(Integer.parseInt(mainid));
                String tid = rs.getString("truck_id");
                mainModel.setTruck_id(Integer.parseInt(tid));
                String desc = rs.getString("description");
                mainModel.setDescription(desc);
                String mdate = rs.getString("maintenance_date");
                mainModel.setMaintenance_date(mdate);
                String tcost = rs.getString("cost");
                mainModel.setCost(Integer.parseInt(tcost));
                maintenanceinfo.add(mainModel);

                //customerinfo.add(Arrays.asList(custid, bname,contact_name,emaild,country));
               
//                customerinfo.add(custid);
//                customerinfo.add(bname);
//                customerinfo.add(contact_name);
//                customerinfo.add(emaild);
//                customerinfo.add(country);
            } 
            
            System.out.println("Maintenance Information" + maintenanceinfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return maintenanceinfo;
    }

}