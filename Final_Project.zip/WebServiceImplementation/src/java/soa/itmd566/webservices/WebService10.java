package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;
import soa.itmd566.model.*;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "customerpaymentInfo", targetNamespace = "http://my.org/ns/")
public class WebService10 {

    @WebMethod(operationName = "getcustomerpaymentInfo")
    public List<CustomerPaymentModel> customerpaymentInfoById() throws Exception {
        List<CustomerPaymentModel> customerpaymentinfo = new ArrayList<>();
        //ArrayList customerinfo = new ArrayList();
        CustomerPaymentModel custpaymodel=null;
        
        try {
            
            Connection con = getConnection();
            String customerInfo="select id, invoice_id, payment_date, payment_method from customerpayment";
            PreparedStatement ps = con.prepareStatement(customerInfo);
            ResultSet rs = ps.executeQuery();
            
           
            while (rs.next()) {
                custpaymodel = new CustomerPaymentModel();
                String cpid = rs.getString("id");
                custpaymodel.setCustomerpaymentid(Integer.parseInt(cpid));
                String cp_invoice_id = rs.getString("invoice_id");
                custpaymodel.setInvoiceid(Integer.parseInt(cp_invoice_id));
                String pay_date = rs.getString("payment_date");
                custpaymodel.setDate(pay_date);
                String pay_mthd = rs.getString("payment_method");
                custpaymodel.setPaymentmethod(pay_mthd);
                customerpaymentinfo.add(custpaymodel);

                //customerinfo.add(Arrays.asList(custid, bname,contact_name,emaild,country));
               
//                customerinfo.add(custid);
//                customerinfo.add(bname);
//                customerinfo.add(contact_name);
//                customerinfo.add(emaild);
//                customerinfo.add(country);
            } 
            
            System.out.println("Customer Information" + customerpaymentinfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerpaymentinfo;
    }

}