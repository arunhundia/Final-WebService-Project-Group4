package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;
import soa.itmd566.model.*;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "CountTruckMaintenanceInfo", targetNamespace = "http://my.org/ns/")
public class WebService17 {

    @WebMethod(operationName = "getcounttruckmaintenance")
    public List<CountMaintenanceModel> counttruckmaintenanceById() throws Exception {
        List<CountMaintenanceModel> cmaintenanceinfo = new ArrayList<>();
        //ArrayList customerinfo = new ArrayList();
        CountMaintenanceModel mainModelinfo=null;
        
        try {
            
            Connection con = getConnection();
            String countmaintenancesql="select t.truck_id Truck_ID, count(m.truck_id) total_count from maintenance m join trucks t on m.truck_id=t.truck_id group by m.truck_id";
            PreparedStatement ps = con.prepareStatement(countmaintenancesql);
            ResultSet rs = ps.executeQuery();
            
           
            while (rs.next()) {
                mainModelinfo = new CountMaintenanceModel();
                String truckid = rs.getString("Truck_ID");
                mainModelinfo.setTruck_id(Integer.parseInt(truckid));
                String tcount = rs.getString("total_count");
                mainModelinfo.setTotal_count(Integer.parseInt(tcount));
                
                cmaintenanceinfo.add(mainModelinfo);

                //customerinfo.add(Arrays.asList(custid, bname,contact_name,emaild,country));
               
//                customerinfo.add(custid);
//                customerinfo.add(bname);
//                customerinfo.add(contact_name);
//                customerinfo.add(emaild);
//                customerinfo.add(country);
            } 
            
            System.out.println("Count of Total Truck Maintenance Information" + cmaintenanceinfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cmaintenanceinfo;
    }

}