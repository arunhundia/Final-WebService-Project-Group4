package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "locationInfo", targetNamespace = "http://my.org/ns/")
public class WebService12 {

    @WebMethod(operationName = "getlocationInfo")
    public String locationInfoById() throws Exception {
        
        ArrayList locationInfo = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from locations;");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String location_id = rs.getString("location_id");
                String location_name = rs.getString("location_name");
                String cust_id = rs.getString("customer_id");
                String address_1 = rs.getString("address1");
                String address_2 = rs.getString("address2");
                String city = rs.getString("city");
                String state = rs.getString("state");
                String zipcode = rs.getString("zipcode");
                String location_contact = rs.getString("location_contact");
                String phone = rs.getString("phone");
                String email = rs.getString("email");

                
                locationInfo.add(location_id);
                locationInfo.add(location_name);
                locationInfo.add(cust_id);
                locationInfo.add(address_1);
                locationInfo.add(address_2);
                locationInfo.add(city);
                locationInfo.add(state);
                locationInfo.add(zipcode);
                locationInfo.add(location_contact);
                locationInfo.add(phone);
                locationInfo.add(email);
                
                
            }
            System.out.println("Location Information" + locationInfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return locationInfo.toString();
    }

}
