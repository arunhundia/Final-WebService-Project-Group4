package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get Maintenance Record between two years
 */
@WebService(serviceName = "InvoiceById", targetNamespace = "http://my.org/ns/")
public class WebService5 {

    @WebMethod(operationName = "getInvoiceById2")
    public String invoiceById() throws Exception {
        
        ArrayList invoice = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from invoice where invoice_id= '" + 2 + "'");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String id = rs.getString("invoice_id");
                String tid = rs.getString("order_id");
                String desc = rs.getString("businessname");
                String mdate = rs.getString("businessphone");
                String cost = rs.getString("businessemail");
                                
                invoice.add(id);
                invoice.add(tid);
                invoice.add(desc);
                invoice.add(mdate);
                invoice.add(cost);
                
            }
            System.out.println("Invoice Details" + invoice.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return invoice.toString();
    }

}
