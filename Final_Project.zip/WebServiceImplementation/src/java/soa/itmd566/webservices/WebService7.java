package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "DriversInfo", targetNamespace = "http://my.org/ns/")
public class WebService7 {

    @WebMethod(operationName = "getDriverInfo")
    public String driverinfoById() throws Exception {
        
        ArrayList driverinfo = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select driver_id,driver_license,driver_name,employee_type from drivers");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String did = rs.getString("driver_id");
                String license = rs.getString("driver_license");
                String dname = rs.getString("driver_name");
                String emo_type = rs.getString("employee_type");
                                
                driverinfo.add(did);
                driverinfo.add(license);
                driverinfo.add(dname);
                driverinfo.add(emo_type);
                
            }
            System.out.println("Driver Information" + driverinfo.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return driverinfo.toString();
    }

}
