package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get vehicle details by make years
 */
@WebService(serviceName = "VehicleByYear", targetNamespace = "http://my.org/ns/")
public class WebService3 {

    @WebMethod(operationName = "getVehicle2017")
    public String vehicleById() throws Exception {
        
        ArrayList vehicle = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from vehicles where year= '" + 2017 + "'");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String id = rs.getString("vehicle_id");
                String vin = rs.getString("vin");
                String colour = rs.getString("colour");
                String make = rs.getString("make");
                String model = rs.getString("model");
                String year = rs.getString("year");
                
                vehicle.add(id);
                vehicle.add(vin);
                vehicle.add(colour);
                vehicle.add(make);
                vehicle.add(model);
                vehicle.add(year);
            }
            System.out.println("Vehicle Details" + vehicle.toString());

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehicle.toString();
    }

}
