package soa.itmd566.webservices;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import static soa.itmd566.webservices.DBConnection.getConnection;

/**
 *
 * @author Karthik
 * WebService to get drivers ticket details by combining to two tables
 */
@WebService(serviceName = "CustomerCountInfo", targetNamespace = "http://my.org/ns/")
public class WebService15 {

    @WebMethod(operationName = "getcustomercountInfo")
    public String customercountById() throws Exception {
        
        ArrayList customercount = new ArrayList();
        
        try {
            
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select c.business_name,count(c.business_name) Total_Count from customers c join orders o on c.customer_id=o.customer_id group by c.business_name");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String business_name = rs.getString("business_name");
                String total_count = rs.getString("Total_Count");               
                

                
                customercount.add(business_name);
                 customercount.add(total_count);
                
            }
            System.out.println("Total Customer Information" + customercount.toString());

            
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customercount.toString();
    }

}
