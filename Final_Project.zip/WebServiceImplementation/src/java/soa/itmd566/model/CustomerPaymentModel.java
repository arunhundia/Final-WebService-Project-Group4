package soa.itmd566.model;

public class CustomerPaymentModel {
int customerpaymentid;
public int getCustomerpaymentid() {
	return customerpaymentid;
}
public void setCustomerpaymentid(int customerpaymentid) {
	this.customerpaymentid = customerpaymentid;
}
public int getInvoiceid() {
	return invoiceid;
}
public void setInvoiceid(int invoiceid) {
	this.invoiceid = invoiceid;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getPaymentmethod() {
	return paymentmethod;
}
public void setPaymentmethod(String paymentmethod) {
	this.paymentmethod = paymentmethod;
}
int invoiceid;
String date;
String paymentmethod;


}

	