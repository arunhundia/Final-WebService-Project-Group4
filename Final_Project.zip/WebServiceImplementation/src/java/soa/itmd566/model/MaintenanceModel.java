/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soa.itmd566.model;

/**
 *
 * @author Arun Hundia
 */
public class MaintenanceModel {

    /**
     * @return the total_count
     */
    public int getTotal_count() {
        return total_count;
    }

    /**
     * @param total_count the total_count to set
     */
    public void setTotal_count(int total_count) {
        this.total_count = total_count;
    }

    /**
     * @return the maintenance_id
     */
    public int getMaintenance_id() {
        return maintenance_id;
    }

    /**
     * @param maintenance_id the maintenance_id to set
     */
    public void setMaintenance_id(int maintenance_id) {
        this.maintenance_id = maintenance_id;
    }

    /**
     * @return the truck_id
     */
    public int getTruck_id() {
        return truck_id;
    }

    /**
     * @param truck_id the truck_id to set
     */
    public void setTruck_id(int truck_id) {
        this.truck_id = truck_id;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the maintenance_date
     */
    public String getMaintenance_date() {
        return maintenance_date;
    }

    /**
     * @param maintenance_date the maintenance_date to set
     */
    public void setMaintenance_date(String maintenance_date) {
        this.maintenance_date = maintenance_date;
    }

    /**
     * @return the cost
     */
    public int getCost() {
        return cost;
    }

    /**
     * @param cost the cost to set
     */
    public void setCost(int cost) {
        this.cost = cost;
    }
    private int maintenance_id;
    private int truck_id;
    private String description;
    private String maintenance_date;
    private int cost;
    private int total_count;
}
