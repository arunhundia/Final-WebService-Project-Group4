/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soa.itmd566.model;

/**
 *
 * @author Arun Hundia
 */
public class CountMaintenanceModel {
    private int truck_id;
    private int total_count;

    /**
     * @return the truck_id
     */
    public int getTruck_id() {
        return truck_id;
    }

    /**
     * @param truck_id the truck_id to set
     */
    public void setTruck_id(int truck_id) {
        this.truck_id = truck_id;
    }

    /**
     * @return the total_count
     */
    public int getTotal_count() {
        return total_count;
    }

    /**
     * @param total_count the total_count to set
     */
    public void setTotal_count(int total_count) {
        this.total_count = total_count;
    }
}
