/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soa.itmd566.model;

/**
 *
 * @author Arun Hundia
 */
public class CustomerLocationOrderModel {

    /**
     * @return the business_name
     */
    public String getBusiness_name() {
        return business_name;
    }

    /**
     * @param business_name the business_name to set
     */
    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }

    /**
     * @return the location_name
     */
    public String getLocation_name() {
        return location_name;
    }

    /**
     * @param location_name the location_name to set
     */
    public void setLocation_name(String location_name) {
        this.location_name = location_name;
    }

    /**
     * @return the total_cost
     */
    public int getTotal_cost() {
        return total_cost;
    }

    /**
     * @param total_cost the total_cost to set
     */
    public void setTotal_cost(int total_cost) {
        this.total_cost = total_cost;
    }
    private String business_name;
    private String location_name;
    private int total_cost;
}
