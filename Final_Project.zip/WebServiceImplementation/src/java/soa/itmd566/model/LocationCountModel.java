/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soa.itmd566.model;

/**
 *
 * @author Arun Hundia
 */
public class LocationCountModel {

    /**
     * @return the lname
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the lname to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    /**
     * @return the total_count
     */
    public int getTotal_count() {
        return total_count;
    }

    /**
     * @param total_count the total_count to set
     */
    public void setTotal_count(int total_count) {
        this.total_count = total_count;
    }
    private String lname;
    private int total_count;
    
}
